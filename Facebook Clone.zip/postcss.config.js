// PostCSS configuration file
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};