// Home page component
"use client";

import { useEffect, useState } from 'react';
import { useSession, signOut } from 'next-auth/react';
import PostList from '@/components/PostList';
import PostForm from '@/components/PostForm';

export default function Home() {
  const { data: session } = useSession();
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    async function fetchPosts() {
      const response = await fetch('/api/posts');
      const data = await response.json();
      setPosts(data);
    }
    fetchPosts();
  }, []);

  if (!session) {
    return (
      <div>
        <p>Not signed in <a href="/api/auth/signin">Sign in</a></p>
      </div>
    );
  }

  return (
    <div>
      <p>Signed in as {session.user?.email} <button onClick={() => signOut()}>Sign out</button></p>
      <PostForm onPostCreated={(newPost) => setPosts([newPost, ...posts])} />
      <PostList posts={posts} />
    </div>
  );
}