// API route for creating and retrieving posts
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma'; // Assuming you have a prisma client instance
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';

export async function GET() {
  try {
    const posts = await prisma.post.findMany({
      include: {
        author: true,
        likes: true,
        comments: {
          include: {
            user: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });
    return NextResponse.json(posts);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to fetch posts' }, { status: 500 });
  }
}

export async function POST(request: Request) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
        return new NextResponse("Unauthorized", { status: 401 });
    }
    const userId = session.user.id; // Assuming userId is in the session

    try {
      const { content, image, video } = await request.json();
      const post = await prisma.post.create({
        data: {
          content,
          image,
          video,
          authorId: userId,
        },
      });
      return NextResponse.json(post, { status: 201 });
    } catch (error) {
      console.error(error);
      return NextResponse.json({ error: 'Failed to create post' }, { status: 500 });
    }
}