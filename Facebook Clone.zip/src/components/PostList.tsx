// Component to display a list of posts
interface Post {
  id: string;
  content: string;
  image?: string;
  video?: string;
  author: {name:string, image:string};
  likes: [];
  comments: [];
  createdAt: string;
}

interface PostListProps {
  posts: Post[];
}

const PostList: React.FC<PostListProps> = ({ posts }) => {
  return (
    <div>
      {posts.map((post) => (
        <div key={post.id} style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '10px' }}>
          <p>Author: {post.author.name}</p>
          <img src={post.author.image || ''} alt="Author" width="50" height="50" />
          <p>{post.content}</p>
          {post.image && <img src={post.image} alt="Post Image" style={{ maxWidth: '100%' }} />}
          <p>Likes: {post.likes.length}</p>
          <p>Comments: {post.comments.length}</p>
          <p>Created At: {new Date(post.createdAt).toLocaleString()}</p>
        </div>
      ))}
    </div>
  );
};

export default PostList;