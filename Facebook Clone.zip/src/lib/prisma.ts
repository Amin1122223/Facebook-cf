// Prisma client instance
import { PrismaClient } from '@prisma/client';

const prismaClientSingleton = () => {
  return new PrismaClient();
};

declare global {
  var prisma: undefined | ReturnType<typeof prismaClientSingleton>;
}

const prisma = globalThis.prisma || prismaClientSingleton();

export type PrismaClientType = typeof prisma;

export { prisma };

if (process.env.NODE_ENV !== 'production') globalThis.prisma = prisma;