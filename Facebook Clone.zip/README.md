# Facebook Clone

A full-stack Facebook clone built with Next.js 14, TypeScript, Tailwind CSS, and Prisma.

## 🚀 الميزات
- User authentication with Google
- Post creation and retrieval
- Real-time post feed
- Responsive design
- Database integration with Prisma

## 🛠️ التقنيات المستخدمة
- Framework: react
- Dependencies: @next-auth/providers, @prisma/client, @tailwindcss/forms, autoprefixer, next, next-auth, next-auth/react, postcss, prisma, react, react-dom, tailwindcss

## 📁 بنية المشروع
The project is structured as follows:
- `next.config.js`: Next.js configuration file.
- `tailwind.config.js`: Tailwind CSS configuration file.
- `postcss.config.js`: PostCSS configuration file.
- `prisma/schema.prisma`: Prisma schema definition.
- `src/app/api/auth/[...nextauth]/route.ts`: NextAuth.js route handler.
- `src/app/api/posts/route.ts`: API route for creating and retrieving posts.
- `src/app/page.tsx`: Home page component.
- `src/components/PostList.tsx`: Component to display a list of posts.
- `src/components/PostForm.tsx`: Component to create a new post.
- `src/lib/prisma.ts`: Prisma client instance.

## ⚡ البدء السريع
```bash
npm install
npm run dev
```

## 🗄️ قاعدة البيانات
```sql
Refer to `prisma/schema.prisma` for the database schema.
```

## 📡 API Endpoints
- /api/auth/[...nextauth] (GET, POST)
- /api/posts (GET, POST)

## 🚀 النشر
### Frontend
Deploy the Next.js application to Vercel.

### Backend
The API routes are part of the Next.js application and will be deployed with the frontend.

### Database
Set up a PostgreSQL database on PlanetScale and configure the `DATABASE_URL` environment variable.
